Password details -- [  username:"Gate1", 
       password:"pass1"  ]
    [  username:"Gate3",
       password:"pass3"  ]
    this two sets of username and password to get in.
-----------------------------------------------------------------------------------------------------------------------
File And Purposes -- [
    login.html - Login page and redirect to correct page if username and password is valid,
    index.html - Html design for parking form and display table,
    jsfile.js  - Javascripting space for the login validation,
    core.js    - Javascripting space for the index file,
    logincss.css & style.css - csscripted file for the login and index pages respectively,

